/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import bean.Cliente;

/**
 *
 * @author ASUS
 */
public class Pedidos {
    
    private int idPedidos;
    private String dataPedido;
    private String statusPedido;
    private String total;
    
    public Pedidos(){
        
    }
    
     public int idPedidos() {
        return idPedidos;
    }
    public void idPedidos(int idPedidos) {
        this.idPedidos = idPedidos;
    }
    
    public String getDataPedido() {
        return dataPedido;
    }
    public void setDataPedido(String dataPedido) {
        this.dataPedido = dataPedido;
    }
    
    public String getDescricao() {
        return statusPedido;
    }
    public void setStatusPedido(String statusPedido) {
        this.statusPedido = statusPedido;
    }
    
    public String getTotal() {
        return total;
    }
    public void setTotal(String total) {
        this.total = total;
    }
    
    
}
