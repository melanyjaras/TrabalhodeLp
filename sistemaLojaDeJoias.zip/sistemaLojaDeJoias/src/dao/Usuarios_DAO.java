/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import bean.Usuarios;
import java.sql.PreparedStatement;
import java.util.Date;

/**
 *
 * @author Melany Jaras
 */
public class Usuarios_DAO extends DAO_abstract{

    @Override
    public void insert(Object object) {
        
        Usuarios usuarios = (Usuarios) object;
        
        String url, user, password;
        //url="jdbc:mysql://10.7.0.51:33062/db_eduardo_aguero";
        url="jdbc:mysql://10.7.0.51:33062/db_melany_salinas";
        user = "melany_salinas";
        password = "melany_salinas";
         try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection cnt;
            cnt = DriverManager.getConnection(url, user, password);
            //Statement stm;
           // stm = cnt.createStatement();
            String sql = "insert into Usuario value(?,?,?,?,?)";
            PreparedStatement pstm = cnt.prepareStatement(sql);
            pstm.setInt(1, usuarios.getIdUsuarios());
            pstm.setString(2, usuarios.getNome());
            pstm.setString(3, usuarios.getSobrenome());
            pstm.setString(4, usuarios.getEmail());
            pstm.setString(5, usuarios.getSenha());
           // pstm.setDate(6, (java.sql.Date) new Date(2021,1,1));
           // stm.executeUpdate(sql);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Usuarios.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Usuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void update(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object list(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List listAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public static void main(String[] args) {
        Usuarios usuarios = new Usuarios();
        usuarios.setIdUsuarios(8);
        usuarios.setNome("gustavo");
        usuarios.setSobrenome("arruda");
        usuarios.setEmail("gustavobarros@gmail.com");
        usuarios.setSenha("3333");
        Usuarios_DAO usuarios_DAO = new Usuarios_DAO();
        usuarios_DAO.insert(usuarios);
        System.out.println("deu certo");
    }
}
