package sistemalojadejoias;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class TesteJDBC {
    public static void main(String[] args) {
        //Class.forName("com.mysql.jdbc.Driver");
        String url, user, password;
        url="jdbc:mysql://localhost:3306/vendas";
        //url="jdbc:mysql://10.7.0.51:33062/db_melany_salinas";
        user = "root";
        password = "";
        Connection cnt;
        try {
            cnt = DriverManager.getConnection(url, user, password);
        } catch (SQLException ex) {
            Logger.getLogger(TesteJDBC.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Conectou");
    }
}
