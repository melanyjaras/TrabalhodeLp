/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import bean.Cliente;

/**
 *
 * @author ASUS
 */
public class Vendas {
    
    private int idVenda;
    private int idCliente;
    private String dataVenda;
    private String total;
    
    public Vendas(){
        
    }
    
     public int idVenda() {
        return idVenda;
    }
    public void idVenda(int idVenda) {
        this.idVenda = idVenda;
    }
    
     public int idCliente() {
        return idCliente;
    }
    public void idCliente(int idCliente) {
        this.idCliente = idCliente;
    }
    
    public String getDataVenda() {
        return dataVenda;
    }
    public void setDataVenda(String dataVenda) {
        this.dataVenda = dataVenda;
    }
    
    public String getTotal() {
        return total;
    }
    public void setTotal(String total) {
        this.total = total;
    }
    
}
