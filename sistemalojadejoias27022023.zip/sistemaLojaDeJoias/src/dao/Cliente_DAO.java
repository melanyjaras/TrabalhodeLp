/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import bean.Cliente;
import java.sql.PreparedStatement;
import java.util.Date;
import sistemalojadejoias.TesteJDBC;

/**
 *
 * @author ASUS
 */
public class Cliente_DAO extends DAO_abstract{
    
    public void insert(Object object) {
        
        Cliente cliente = (Cliente) object;
        
        String url, user, password;
        //url="jdbc:mysql://10.7.0.51:33062/db_eduardo_aguero";
        url="jdbc:mysql://10.7.0.51:33062/db_melany_salinas";
        user = "melany_salinas";
        password = "melany_salinas";
         try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection cnt;
            cnt = DriverManager.getConnection(url, user, password);
            //Statement stm;
           // stm = cnt.createStatement();
            String sql = "insert into Usuario value(?,?,?,?,?)";
            PreparedStatement pstm = cnt.prepareStatement(sql);
            /**pstm.setInt(1, cliente.getIdUsuarios());
            pstm.setString(2, cliente.getNome());
            pstm.setString(3, cliente.getSobrenome());
            pstm.setString(4, cliente.getEmail());
            pstm.setString(5, cliente.getSenha());*/
           // pstm.setDate(6, (java.sql.Date) new Date(2021,1,1));
           // stm.executeUpdate(sql);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void update(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object list(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List listAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


}
